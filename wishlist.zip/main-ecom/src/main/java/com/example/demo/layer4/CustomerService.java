package com.example.demo.layer4;

import java.util.List;

import com.example.demo.WishlistException.WishlistException;
import com.example.demo.getset.Wishlist;

public interface CustomerService {

	
	public boolean addToWishlist(int uId, int pId);
	public boolean deleteWishlist(int wId) throws WishlistException ;
	public List<Wishlist> getWishlistValues(int uId);
}
