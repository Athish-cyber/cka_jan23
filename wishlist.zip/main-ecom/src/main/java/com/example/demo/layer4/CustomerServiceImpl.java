package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.WishlistException.WishlistException;
import com.example.demo.getset.Wishlist;
import com.example.demo.layer3.WishlistDAO;



@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private WishlistDAO wishlistDAO;

	
	@Override
	public boolean addToWishlist(int uId, int pId) {
		// TODO Auto-generated method stub
		return this.wishlistDAO.addToWishlist(uId, pId);
	}

	@Override
	public boolean deleteWishlist(int w_Id) throws WishlistException {
		// TODO Auto-generated method stub
		System.out.println(w_Id+" Service");
		return this.wishlistDAO.deleteWishlist(w_Id);
	}
	
	@Override
	public List<Wishlist> getWishlistValues(int uId) {
		// TODO Auto-generated method stub
		return this.wishlistDAO.getWishlistOfUser(uId);
	}

}
