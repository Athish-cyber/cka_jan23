package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.WishlistException.WishlistException;
import com.example.demo.getset.Wishlist;
import com.example.demo.layer2.ProductTable;
import com.example.demo.layer2.UserTable;
import com.example.demo.layer2.WishlistTable;



@Repository
public class WishlistDAOImpl implements WishlistDAO {
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	@Transactional
	public boolean addToWishlist(int uId, int pId)
	{
		UserTable user =  this.entityManager.find(UserTable.class, uId);
		System.out.println(user.getUId());
		ProductTable product = this.entityManager.find(ProductTable.class, pId);
		WishlistTable wishlist = new WishlistTable();
		wishlist.setUserTable(user);
		wishlist.setProductTable(product);
		this.entityManager.persist(wishlist);
		return true;
	}
	
	
	@Override
	@Transactional
	public boolean deleteWishlist(int w_Id) throws WishlistException
	{
		System.out.println(w_Id+" Repo");
		WishlistTable cart = this.entityManager.find(WishlistTable.class, w_Id);
		this.entityManager.remove(cart);
		return true;
	}
	
	@Override
	public List<Wishlist> getWishlistOfUser(int uId) {
		// TODO Auto-generated method stub
		List<Wishlist> wishlists = new ArrayList<Wishlist>();
		UserTable user = (UserTable)this.entityManager.find(UserTable.class, uId);
		System.out.println("User is :"+user);
		String q = "from WishlistTable where userTable=:x";
		Query query = (Query)this.entityManager.createQuery(q);
		query.setParameter("x", user);
		List<WishlistTable> wishlistTables = query.getResultList();
		//System.out.println("Cart values are :"+query.getResultList().toString());
		for(WishlistTable w : wishlistTables)
		{
			int wId = w.getWId();
			int pId = w.getProductTable().getPId();
			String pName = w.getProductTable().getPName();
			String pBrand = w.getProductTable().getPBrand();
			int pPrice = w.getProductTable().getPPrice();
			String pImage1 = w.getProductTable().getPImage1();
			wishlists.add(new Wishlist(pId,pName,pBrand,pPrice,wId,pImage1));
		}
		return wishlists;
	}
}
