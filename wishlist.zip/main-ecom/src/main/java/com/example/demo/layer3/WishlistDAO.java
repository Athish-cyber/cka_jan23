package com.example.demo.layer3;

import java.util.List;

import com.example.demo.WishlistException.WishlistException;
import com.example.demo.getset.Wishlist;


public interface WishlistDAO {
	public boolean addToWishlist(int uId, int pId);
	public boolean deleteWishlist(int wId) throws WishlistException;
	public List<Wishlist> getWishlistOfUser(int uId);
}