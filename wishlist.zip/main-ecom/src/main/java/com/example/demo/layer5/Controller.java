package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.getset.Wishlist;
import com.example.demo.layer4.CustomerService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class Controller {

	@Autowired
	private CustomerService customerService;

	@PostMapping(path = "/addToMyWishlist/{uId}/{pId}") 
	public String updateMyWishlist(@PathVariable int uId, @PathVariable int pId)
	{
		boolean ok = this.customerService.addToWishlist(uId,pId);
		if(ok==true)
			return "Product Added to Wishlist Successfull";
		return "Cannot Add Product to Wishlist";
	}
	
	@DeleteMapping(path = "/deleteMyWishlist/{w_Id}") 
	public String deleteMyWishlist(@PathVariable int w_Id)
	{
		try
		{
			boolean ok = this.customerService.deleteWishlist(w_Id);
			return "Wish Unchecked";
		}
		catch(Exception e)
		{
		  System.out.print(e.getMessage());
		  return "error";
		}
	}
	
	@GetMapping(path = "/getMyWishlist/{uId}") 
	public List<Wishlist> getMyWishlist(@PathVariable String uId)
	{
		return this.customerService.getWishlistValues(Integer.parseInt(uId));
	}
}
