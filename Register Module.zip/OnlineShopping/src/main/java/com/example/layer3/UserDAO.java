package com.example.layer3;

import java.util.List;

import com.example.getset.UserSignUp;
import com.example.layer2.CartTable;
import com.example.layer2.UserTable;
import com.example.layer3.exception.CustomerException;

public interface UserDAO {
	public UserTable getUserByEmail(String email) throws CustomerException;
	public int addUser(UserSignUp newUser);
}
