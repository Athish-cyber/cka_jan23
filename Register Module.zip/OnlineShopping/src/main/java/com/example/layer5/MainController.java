package com.example.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.getset.UserSignUp;
import com.example.layer2.CartTable;
import com.example.layer2.ProductTable;
import com.example.layer2.RetailerTable;
import com.example.layer2.UserTable;
import com.example.layer2.WishlistTable;
import com.example.layer3.exception.CustomerException;
import com.example.layer4.CustomerService;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MainController {

	
	@Autowired
	private CustomerService customerService;

	
	
	@GetMapping(path = "/index") 
	public String home()
	{
		return "Welcome to EasyBuy ";
	}
	 
	@PostMapping(path = "/addNewUser")
	public int addNewUser(@RequestBody UserSignUp newUser)
	{
		return this.customerService.addUser(newUser);
	}
	
	
}
