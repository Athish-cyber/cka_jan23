	package com.example.layer4;

import java.util.List;

import javax.persistence.NonUniqueResultException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.getset.UserSignUp;
import com.example.layer2.CartTable;
import com.example.layer2.UserTable;
import com.example.layer3.UserDAO;
import com.example.layer3.exception.CustomerException;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private UserDAO userDAO;
	

	@Override
	public int addUser(UserSignUp newUser) {
		int id = 0;
		try
		{
			UserTable user = this.userDAO.getUserByEmail(newUser.getuEmail());
			return -1;
		}
		catch(NullPointerException e)
		{
			return -1;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			id = this.userDAO.addUser(newUser);
		}
		return id;
	}
	
	

}
