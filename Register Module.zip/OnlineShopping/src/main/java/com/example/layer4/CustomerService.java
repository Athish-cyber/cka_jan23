package com.example.layer4;

import java.util.List;

import com.example.getset.UserSignUp;
import com.example.layer2.CartTable;
import com.example.layer2.UserTable;
import com.example.layer3.exception.CustomerException;


public interface CustomerService {
	
	public int addUser(UserSignUp newUser);
	
}
